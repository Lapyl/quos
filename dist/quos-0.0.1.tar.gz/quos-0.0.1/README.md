# Quos package

for simulating quantum computing based on oscillatory quota

### How to install

pip install quos

### How to upgrade

pip install --upgrade quos

### How to use

import quos
or
from quos import \*

### Modules included

### Version History

- 0.0.1 2023-11-07 Initial release
