# Quos package

for simulating quantum computing based on oscillatory quota

### How to install

pip install matplotlib networkx
pip install quos

### How to upgrade

pip install --upgrade quos

### How to use

import quos
or
from quos import \*

### Modules included

icons

### Version History

- 0.0.1 2023-11-07 Initial release
- 0.0.2 2023-11-07 Minor corrections
- 0.0.3 2023-11-07 Minor corrections
- 0.0.4 2023-11-07 Minor corrections
